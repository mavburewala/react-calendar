# stylelint

stylelint catches bugs and helps keep you and your team on consistent with the
standards and conventions you define.

We've pre-configured it to extend [stylelint-config-standard](https://github.com/stylelint/stylelint-config-standard)
but you can (and should!) adapt it to your house style.

See the [official documentation](http://stylelint.io/) for more information!
