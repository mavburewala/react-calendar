/**
 * Homepage selectors
 */
