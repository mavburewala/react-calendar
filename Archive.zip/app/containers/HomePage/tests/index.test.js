/**
 * Test the HomePage
 */

