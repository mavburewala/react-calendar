/**
 * Test the HomePage
 */
