# React Calendar

## Quick start

1. Clone this repo using `git clone  https://github.com/mavburewala/react-calendar.git`
1. Run `npm run setup` to install dependencies and clean the git repo.<br />
   *At this point you can run `npm start` to see the calendar app at `http://localhost:3000`.*
1. Run `npm run clean` to delete the calendar app.

Now you're ready to rumble!
